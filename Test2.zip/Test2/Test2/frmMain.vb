﻿'''''
'''Lance Brown
'''7/8/20
'''Test 2
'''''

Option Strict On
Public Class frmMain
    Dim arrCounty(7) As Integer
    Dim arrIncome(7) As Double

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If Validate(txtIncome.Text) Then
            If String.IsNullOrEmpty(cboCounty.SelectedItem.ToString) Then
                ErrHandle(cboCounty)
                Return
            End If
            Dim index As Integer = cboCounty.SelectedIndex
            arrCounty(index) = arrCounty(index) + 1
            arrIncome(index) = arrIncome(index) + CType(txtIncome.Text, Double)

            Clear()
        End If
    End Sub
    Private Function Validate(ByVal strIncome As String) As Boolean
        Dim blnValid = False
        Dim dblIncome As Double
        If Double.TryParse(strIncome, dblIncome) And dblIncome > 0 And Not String.IsNullOrEmpty(strIncome) Then
            blnValid = True
        Else
            ErrHandle(txtIncome)
        End If
        Return blnValid
    End Function
    Private Sub ErrHandle(ctrl As Control)
        ctrl.BackColor = Color.Yellow
        ctrl.Select()
        MessageBox.Show("Invalid input", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

    End Sub
    Private Sub Clear()
        For Each ctrl As Control In Controls
            If TypeOf ctrl Is ComboBox Then
                CType(ctrl, ComboBox).SelectedIndex = -1
            ElseIf TypeOf ctrl Is TextBox Then
                CType(ctrl, TextBox).ResetText()
                ctrl.BackColor = Color.Empty
            End If
        Next
    End Sub

    Private Sub btnTotal_Click(sender As Object, e As EventArgs) Handles btnTotal.Click
        Dim strOutput As String = "Ohio:" & ChrW(9) & ChrW(9) & ChrW(9) & (arrCounty(0) + arrCounty(1) + arrCounty(2) + arrCounty(3)).ToString & vbCrLf & ChrW(9) & "Hamilton:" & ChrW(9) & arrCounty(0).ToString & vbCrLf & ChrW(9) & "Butler:" & ChrW(9) & ChrW(9) & arrCounty(1).ToString & vbCrLf & ChrW(9) & "Clermont:" & ChrW(9) & arrCounty(2).ToString & vbCrLf & ChrW(9) & "Warren:" & ChrW(9) & ChrW(9) & arrCounty(3).ToString & vbCrLf & "Kentucky:" & ChrW(9) & ChrW(9) & (arrCounty(4) + arrCounty(5) + arrCounty(6)).ToString & vbCrLf & ChrW(9) & "Boone:" & ChrW(9) & ChrW(9) & arrCounty(4).ToString & vbCrLf & ChrW(9) & "Campbell:" & ChrW(9) & arrCounty(5).ToString & vbCrLf & ChrW(9) & "Kenton:" & ChrW(9) & ChrW(9) & arrCounty(6).ToString
        MessageBox.Show(strOutput, "Total Households Surveyed", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub btnIncome_Click(sender As Object, e As EventArgs) Handles btnIncome.Click
        Dim strOutput As String = "Ohio:" & ChrW(9) & ChrW(9) & ChrW(9) & ((arrIncome(0) + arrIncome(1) + arrIncome(2) + arrIncome(3)) / (arrCounty(0) + arrCounty(1) + arrCounty(2) + arrCounty(3))).ToString("$###,###,##0.00") & vbCrLf & ChrW(9) & "Hamilton:" & ChrW(9) & (arrIncome(0) / arrCounty(0)).ToString("$###,###,##0.00") & vbCrLf & ChrW(9) & "Butler:" & ChrW(9) & ChrW(9) & (arrIncome(1) / arrCounty(1)).ToString("$###,###,##0.00") & vbCrLf & ChrW(9) & "Clermont:" & ChrW(9) & (arrIncome(0) / arrCounty(0)).ToString("$###,###,##0.00") & vbCrLf & ChrW(9) & "Warren:" & ChrW(9) & ChrW(9) & (arrIncome(3) / arrCounty(3)).ToString("$###,###,##0.00") & vbCrLf & "Kentucky:" & ChrW(9) & ChrW(9) & ((arrIncome(4) + arrIncome(5) + arrIncome(6)) / (arrCounty(4) + arrCounty(5) + arrCounty(6))).ToString("$###,###,##0.00") & vbCrLf & ChrW(9) & "Boone:" & ChrW(9) & ChrW(9) & (arrIncome(4) / arrCounty(4)).ToString("$###,###,##0.00") & vbCrLf & ChrW(9) & "Campbell:" & ChrW(9) & (arrIncome(5) / arrCounty(5)).ToString("$###,###,##0.00") & vbCrLf & ChrW(9) & "Kenton:" & ChrW(9) & ChrW(9) & (arrIncome(6) / arrCounty(6)).ToString("$###,###,##0.00")
        MessageBox.Show(strOutput, "Average Household Income", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class
